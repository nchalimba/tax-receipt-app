Speichen Sie in diesem Ordner das vollständige *Android Studio*-Projekt Ihrer App ab.
